package com.ems.main.service;

import java.util.List;

import com.ems.main.dto.StudentDTO;

public interface StudentService {

	public void createOrUpdateEmployee(StudentDTO empDTO);
	
	public List<StudentDTO> getAllEmployee();
	
	public void deleteEmployee(Long id);
	
	public StudentDTO editEmployee(Long id);
	
}
