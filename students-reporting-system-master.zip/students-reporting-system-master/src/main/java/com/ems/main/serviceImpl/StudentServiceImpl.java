package com.ems.main.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ems.main.dto.StudentDTO;
import com.ems.main.model.Student;
import com.ems.main.repository.StudentRepository;
import com.ems.main.service.StudentService;

@Service
public class StudentServiceImpl implements StudentService{
	
	@Autowired
	private StudentRepository employeeRepository;

	public void createOrUpdateEmployee(StudentDTO empDto) {
		Student emp = convertDtoToModel(empDto);
		employeeRepository.save(emp);
	}
	
	public List<StudentDTO> getAllEmployee() {
		List<Student> list = employeeRepository.findAll();
		List<StudentDTO> employeeList = list.stream()
	            .map(StudentDTO::new)
	            .collect(Collectors.toCollection(ArrayList::new));
		return employeeList;
	}
	
	public void deleteEmployee(Long id) {
		employeeRepository.deleteById(id);
	}
	
	public StudentDTO editEmployee(Long id) {
		Student emp = employeeRepository.getOne(id);
		return convertModelToDTO(emp);
	}
	
	private Student convertDtoToModel(StudentDTO empDto) {
		Student emp = new Student();
		if (empDto.getId() != null) {
			emp.setId(empDto.getId());
		}
		emp.setAge(empDto.getAge());
		emp.setBloodGp(empDto.getBloodGp());
		emp.setEmailId(empDto.getEmailId());
		emp.setEmpId(empDto.getEmpId());
		emp.setFirstName(empDto.getFirstName());
		emp.setLastName(empDto.getLastName());
		emp.setMobileNo(empDto.getMobileNo());
		emp.setPersonalEmail(empDto.getPersonalEmail());
		emp.setUserName(empDto.getUserName());
		return emp;
	}
	
	private StudentDTO convertModelToDTO(Student emp) {
		StudentDTO empDTO = new StudentDTO();
		empDTO.setId(emp.getId());
		empDTO.setAge(emp.getAge());
		empDTO.setBloodGp(emp.getBloodGp());
		empDTO.setEmailId(emp.getEmailId());
		empDTO.setEmpId(emp.getEmpId());
		empDTO.setFirstName(emp.getFirstName());
		empDTO.setLastName(emp.getLastName());
		empDTO.setMobileNo(emp.getMobileNo());
		empDTO.setPersonalEmail(emp.getPersonalEmail());
		empDTO.setUserName(emp.getUserName());
		return empDTO;
	}
}
